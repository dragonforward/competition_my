import sys
import cv2
import time
import base64
import threading
import serial
import socketio
import numpy as np
import random
import requests
import io
from datetime import datetime
import json
from periphery import GPIO
import dht11
from yolov5_detect import post_process, draw

sys.path.append('/root/rknn_model_zoo')
sys.path.append('/home/elf/Desktop/servo/python')
from py_utils.coco_utils import COCO_test_helper
from py_utils.rknn_executor import RKNN_model_container 

import pwm_servo

# ========== 初始化全局变量 ==========
upload_flag = False
detector_building = None
detector_safety = None
detection_building_enabled = False
detection_safety_enabled = False
show_overlay = False  # 是否显示检测框

# 舵机初始化
servo1 = pwm_servo.PWMServo("pwmchip0", 0)
servo2 = pwm_servo.PWMServo("pwmchip1", 0)
servo1.set_polarity("normal")
servo2.set_polarity("normal")

# 初始化 DHT11
GPIO_CHIP = "/dev/gpiochip3"
GPIO_LINE = 11
dht_sensor = dht11.DHT11(gpio_chip=GPIO_CHIP, gpio_line=GPIO_LINE)

angle1 = 90
angle2 = 120
servo1.set_angle(angle1)
servo2.set_angle(angle2)

serial_port = serial.Serial(
    port='/dev/ttyS9',
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=0.5
)

def clamp(val):
    return max(0, min(180, val))

# ========== 模型初始化 ==========
def init_detectors():
    global detector_building, detector_safety
    
    # 建材模型
    building_anchor_path = "/home/elf/Desktop/udisk/anchors_yolov5.txt"
    building_model_path = "/root/rknn_jiancai_yolov5/yolov5_jiancai.rknn"
    building_helper = COCO_test_helper(enable_letter_box=True)
    building_model = RKNN_model_container(building_model_path, 'rk3588', None)
    with open(building_anchor_path, 'r') as f:
        building_anchors = [float(v) for v in f.readlines()]
        building_anchors = np.array(building_anchors).reshape(3, -1, 2).tolist()
    detector_building = {
        "model": building_model,
        "anchors": building_anchors,
        "helper": building_helper,
        "classes": ["coil", "brickwork", "rebar"]
    }

    # 安全帽模型
    safety_anchor_path = "/home/elf/Desktop/udisk/anchors_yolov5.txt"
    safety_model_path = "/root/rknn_jiancai_yolov5/yolov5_hat.rknn"
    safety_helper = COCO_test_helper(enable_letter_box=True)
    safety_model = RKNN_model_container(safety_model_path, 'rk3588', None)
    with open(safety_anchor_path, 'r') as f:
        safety_anchors = [float(v) for v in f.readlines()]
        safety_anchors = np.array(safety_anchors).reshape(3, -1, 2).tolist()
    detector_safety = {
        "model": safety_model,
        "anchors": safety_anchors,
        "helper": safety_helper,
        "classes": ["head", "helmet", "person"]
    }

def handle_command(cmd):
    global angle1, angle2,upload_flag
    print("收到指令：", cmd)

    if cmd == "servo1_left":
        angle1 = clamp(angle1 + 2)
        servo1.set_angle(angle1)
    elif cmd == "servo1_right":
        angle1 = clamp(angle1 - 2)
        servo1.set_angle(angle1)
    elif cmd == "servo2_up":
        angle2 = clamp(angle2 - 2)
        servo2.set_angle(angle2)
    elif cmd == "servo2_down":
        angle2 = clamp(angle2 + 2)
        servo2.set_angle(angle2)
    elif cmd == "car_forward":
        serial_port.write(("front").encode('utf-8'))
    elif cmd == "car_backward":
        serial_port.write(("behind").encode('utf-8'))
    elif cmd == "car_left":
        serial_port.write(("turn_left").encode('utf-8'))
    elif cmd == "car_right":
        serial_port.write(("turn_right").encode('utf-8'))
    elif cmd == "stop":
        serial_port.write(("stop").encode('utf-8'))
    elif cmd == "upload_image":
        print("上传")
        upload_flag=True

# ========== SocketIO ==========
sio = socketio.Client()

@sio.event
def connect():
    print("连接服务器成功")
    # 连接时同步显示检测框状态
    sio.emit("overlay_status", {"enabled": show_overlay})

@sio.event
def disconnect():
    print("服务器断开连接")

@sio.on('control')
def on_control(data):
    cmd = data.get('command')
    if cmd:
        handle_command(cmd)

@sio.on('building_detection_status')
def on_building_detection_status(data):
    global detection_building_enabled
    detection_building_enabled = data.get('enabled', False)
    print(f"[SocketIO] 建材识别检测状态: {'开启' if detection_building_enabled else '关闭'}")

@sio.on('safety_detection_status')
def on_safety_detection_status(data):
    global detection_safety_enabled
    detection_safety_enabled = data.get('enabled', False)
    print(f"[SocketIO] 安全检测状态: {'开启' if detection_safety_enabled else '关闭'}")

@sio.on('overlay_status')
def on_overlay_status(data):
    global show_overlay
    show_overlay = data.get('enabled', False)
    print(f"[SocketIO] 显示检测框状态: {'开启' if show_overlay else '关闭'}")

# ========== 推理函数 ==========
def process_detection(frame, detector):
    img = detector["helper"].letter_box(frame.copy(), new_shape=(640, 640))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    input_data = np.expand_dims(img, 0)
    outputs = detector["model"].run([input_data])
    boxes, classes, scores = post_process(outputs, detector["anchors"])
    return boxes, classes, scores


def upload_image_to_onenet(img_draw):
    try:
        # 编码图像为JPEG二进制
        _, buffer = cv2.imencode('.jpg', img_draw)
        image_io = io.BytesIO(buffer.tobytes())

        # 时间戳命名
        filename = datetime.now().strftime("%Y%m%d_%H%M%S") + ".jpg"

        url = "https://iot-api.heclouds.com/device/file-upload"
        headers = {
            'Authorization': 'version=2020-05-29&res=userid%2F227664&et=1783500627&method=sha1&sign=%2Fw7%2B1DvSYi%2Bk4M3NFnCVbCOQeAk%3D'
        }
        payload = {'device_name': 'licheepi4a', 'product_id': 'fs1W2mxU41'}
        files = [('file', (filename, image_io, 'image/jpeg'))]

        response = requests.post(url, headers=headers, data=payload, files=files)
        print("✅ 图像上传结果:", response.text)
    except Exception as e:
        print("❌ 图像上传异常:", e)

# ========== 摄像头线程 ==========
def send_camera_loop():
    global upload_flag
    cap = cv2.VideoCapture('/dev/video21')
    last_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        try:
            img_draw = frame.copy()
            if upload_flag:
                upload_flag = False  # 清除上传标志
                threading.Thread(target=upload_image_to_onenet, args=(frame.copy(),)).start()

            if detection_building_enabled:
                boxes, classes, scores = process_detection(frame, detector_building)
                counts = {"brickwork": 0, "coil": 0, "rebar": 0}
                if boxes is not None:
                    for cls in classes:
                        cls_name = detector_building["classes"][cls] if cls < len(detector_building["classes"]) else None
                        if cls_name in counts:
                            counts[cls_name] += 1
                    if show_overlay:
                        draw(img_draw, detector_building["helper"].get_real_box(boxes), scores, classes, detector_building["classes"])
                sio.emit('building_detection_result', counts)
            else :
                sio.emit('building_detection_result', {"brickwork": 0, "coil": 0, "rebar": 0})

            if detection_safety_enabled:
                boxes, classes, scores = process_detection(frame, detector_safety)
                no_head_detected = False
                if boxes is not None:
                    for cls in classes:
                        if detector_safety["classes"][cls] == "head":
                            no_head_detected = True
                            break
                    if show_overlay:
                        draw(img_draw, detector_safety["helper"].get_real_box(boxes), scores, classes, detector_safety["classes"])
                sio.emit('safety_detection_result', {"no_head_detected": no_head_detected})
            else :
                sio.emit('safety_detection_result', {"no_head_detected": False})
            

            _, buffer = cv2.imencode('.jpg', img_draw, [int(cv2.IMWRITE_JPEG_QUALITY), 60])
            img_str = base64.b64encode(buffer).decode('utf-8')

            now = time.time()
            if now - last_time > 0.1:
                last_time = now
                sio.emit('video_frame', {"img": img_str})
            

        except Exception as e:
            print("目标检测异常:", e)
            continue

# ========== 温湿度线程 ==========
def send_temp_humidity_loop():
    global dht_sensor
    last_valid_temp = 22.0
    last_valid_humi = 75.0
    # 固定参数配置
    url = "https://open.iot.10086.cn/fuse/http/device/thing/property/post?topic=$sys/fs1W2mxU41/licheepi4a/thing/property/post&protocol=http"
    headers = {
        'Token': 'version=2018-10-31&res=products%2Ffs1W2mxU41%2Fdevices%2Flicheepi4a&et=2000000000&method=sha1&sign=o61WwccEporKXiJyNL3lbUseqdw%3D',
        'Content-Type': 'application/json'
    }
    try:
        while True:
            result = dht_sensor.read()
            if result.is_valid():
                last_valid_temp = result.temperature
                last_valid_humi = result.humidity
            sio.emit('temperature_humidity', {
                'temperature': float(last_valid_temp),
                'humidity': float(last_valid_humi)
            })
            time.sleep(2)
            # 👉 向 OneNET 平台发送数据
            try:
                payload = json.dumps({
                    "id": "123",
                    "version": "1.0",
                    "params": {
                        "temp": { "value": last_valid_temp },
                        "hum": { "value": last_valid_humi }
                    }
                })
                response = requests.post(url, headers=headers, data=payload)
            except Exception as e:
                print("发送异常")

            
    except Exception as e:
        pass
    finally:
        del dht_sensor

# ========== 启动 ==========
if __name__ == "__main__":
    init_detectors()
    sio.connect('http://192.168.31.246:5000')
    threading.Thread(target=send_camera_loop, daemon=True).start() 
    threading.Thread(target=send_temp_humidity_loop, daemon=True).start()
    sio.wait()
