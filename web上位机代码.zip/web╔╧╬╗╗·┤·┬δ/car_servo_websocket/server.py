import eventlet
eventlet.monkey_patch()

from flask import Flask, render_template
from flask_socketio import SocketIO, emit

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins='*')

current_command = "stop"
detection_building_enabled = False
detection_safety_enabled = False
show_overlay = False  # ✅ 新增：是否显示检测框

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('control')
def handle_control(data):
    global current_command
    current_command = data.get('command', 'stop')
    print("[Web] 控制指令:", current_command)
    socketio.emit('control', {'command': current_command})

@socketio.on('toggle_building_detection')
def handle_toggle_building(data):
    global detection_building_enabled
    detection_building_enabled = data.get('enabled', False)
    print(f"[Web] 建材识别检测开关: {'开启' if detection_building_enabled else '关闭'}")
    socketio.emit('building_detection_status', {'enabled': detection_building_enabled})

@socketio.on('toggle_safety_detection')
def handle_toggle_safety(data):
    global detection_safety_enabled
    detection_safety_enabled = data.get('enabled', False)
    print(f"[Web] 安全检测开关: {'开启' if detection_safety_enabled else '关闭'}")
    socketio.emit('safety_detection_status', {'enabled': detection_safety_enabled})

@socketio.on('toggle_overlay')
def handle_toggle_overlay(data):
    global show_overlay
    show_overlay = data.get('enabled', False)
    print(f"[Web] 显示检测框开关: {'开启' if show_overlay else '关闭'}")
    socketio.emit('overlay_status', {'enabled': show_overlay})  # ✅ 广播状态

@socketio.on('video_frame')
def handle_video(data):
    socketio.emit('video_frame', data)

@socketio.on('building_detection_result')
def handle_building_detection_result(data):
    socketio.emit('building_detection_result', data)

@socketio.on('safety_detection_result')
def handle_safety_detection_result(data):
    socketio.emit('safety_detection_result', data)

@socketio.on('temperature_humidity')
def handle_temp_humi(data):
    socketio.emit('temperature_humidity', data)

@socketio.on('connect')
def on_connect():
    print("[Web] 浏览器连接成功")
    emit('building_detection_status', {'enabled': detection_building_enabled})
    emit('safety_detection_status', {'enabled': detection_safety_enabled})
    emit('overlay_status', {'enabled': show_overlay})  # ✅ 初始状态同步

@socketio.on('disconnect')
def on_disconnect():
    print("[Web] 浏览器断开")

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
